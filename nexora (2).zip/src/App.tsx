import { useState, useEffect } from 'react';
import type { AppView, StudySession, WorkspaceTab, QuizResult } from './types';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { UploadView } from './components/UploadView';
import { ProcessingView } from './components/ProcessingView';
import { StudySessionView } from './components/StudySessionView';
import { ApiKeyModal } from './components/ApiKeyModal';
import {
  loadSessions,
  saveSession,
  deleteSession,
  updateSessionQuizResults,
  getDemoSession
} from './services/storageService';
import { extractTextFromFile } from './services/documentExtractor';
import { generateStudySession } from './services/aiService';

export function App() {
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [currentSession, setCurrentSession] = useState<StudySession | null>(null);
  const [initialWorkspaceTab, setInitialWorkspaceTab] = useState<WorkspaceTab>('notes');

  // Processing state
  const [processingProgress, setProcessingProgress] = useState<number>(0);
  const [processingStep, setProcessingStep] = useState<string>('Initializing analysis...');
  const [processingFileName, setProcessingFileName] = useState<string>('');

  // API Key modal
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState<boolean>(false);

  // Load persisted sessions on mount
  useEffect(() => {
    const loaded = loadSessions();
    setSessions(loaded);
  }, []);

  const handleNavigateDashboard = () => {
    setCurrentView('dashboard');
    setCurrentSession(null);
  };

  const handleOpenSession = (session: StudySession, tab: WorkspaceTab = 'notes') => {
    setCurrentSession(session);
    setInitialWorkspaceTab(session.results ? 'results' : tab);
    setCurrentView('workspace');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = deleteSession(id);
    setSessions(updated);
    if (currentSession?.id === id) {
      setCurrentSession(null);
      setCurrentView('dashboard');
    }
  };

  const handleNewSession = () => {
    setCurrentView('upload');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartDemo = async () => {
    setProcessingFileName('Lecture_07_BST_and_AVL_Trees.pdf');
    setCurrentView('processing');
    setProcessingProgress(15);
    setProcessingStep('Reading lecture material and parsing sections...');

    await new Promise((r) => setTimeout(r, 450));
    setProcessingProgress(45);
    setProcessingStep('Extracting key concepts, formulas & definitions...');

    await new Promise((r) => setTimeout(r, 550));
    setProcessingProgress(75);
    setProcessingStep('Structuring exam-oriented revision notes...');

    await new Promise((r) => setTimeout(r, 450));
    setProcessingProgress(90);
    setProcessingStep('Formulating grounded practice quiz & topic mapping...');

    await new Promise((r) => setTimeout(r, 400));
    setProcessingProgress(100);
    setProcessingStep('Study session ready!');

    await new Promise((r) => setTimeout(r, 300));

    const demoSession = getDemoSession();
    // Add to sessions list
    const updated = saveSession(demoSession);
    setSessions(updated);
    setCurrentSession(demoSession);
    setInitialWorkspaceTab('notes');
    setCurrentView('workspace');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleProcessFile = async (file: File) => {
    setProcessingFileName(file.name);
    setCurrentView('processing');
    setProcessingProgress(10);
    setProcessingStep('Extracting text content and lecture slides...');

    try {
      const extractedDoc = await extractTextFromFile(file);

      const generated = await generateStudySession({
        title: extractedDoc.title,
        extractedText: extractedDoc.extractedText,
        fileName: extractedDoc.fileName,
        fileSize: extractedDoc.fileSize,
        pageCount: extractedDoc.pageCount,
        onProgress: (step, progress) => {
          setProcessingStep(step);
          setProcessingProgress(progress);
        }
      });

      const updated = saveSession(generated);
      setSessions(updated);
      setCurrentSession(generated);
      setInitialWorkspaceTab('notes');
      setCurrentView('workspace');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error('Failed to generate study session:', err);
      alert('An error occurred while generating the study session. Please try again or test the instant demo.');
      setCurrentView('upload');
    }
  };

  const handleUpdateQuizResults = (results: QuizResult) => {
    if (!currentSession) return;
    const { updatedSessions, updatedSession } = updateSessionQuizResults(
      currentSession.id,
      results
    );
    setSessions(updatedSessions);
    if (updatedSession) {
      setCurrentSession(updatedSession);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* Universal App Header */}
      <Header
        currentView={currentView}
        currentSession={currentSession}
        onNavigateDashboard={handleNavigateDashboard}
        onStartDemo={handleStartDemo}
        onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {currentView === 'dashboard' && (
          <DashboardView
            sessions={sessions}
            onNewSession={handleNewSession}
            onOpenSession={handleOpenSession}
            onDeleteSession={handleDeleteSession}
            onStartDemo={handleStartDemo}
          />
        )}

        {currentView === 'upload' && (
          <UploadView
            onProcessFile={handleProcessFile}
            onStartDemo={handleStartDemo}
          />
        )}

        {currentView === 'processing' && (
          <ProcessingView
            currentStepMessage={processingStep}
            progressPercent={processingProgress}
            fileName={processingFileName}
          />
        )}

        {currentView === 'workspace' && currentSession && (
          <StudySessionView
            key={currentSession.id}
            session={currentSession}
            initialTab={initialWorkspaceTab}
            onUpdateQuizResults={handleUpdateQuizResults}
          />
        )}
      </main>

      {/* Optional API Key Configuration Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
      />
    </div>
  );
}

export default App;
