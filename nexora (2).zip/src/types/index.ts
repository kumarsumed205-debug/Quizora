export interface KeyConcept {
  id: string;
  title: string;
  summary: string;
  sourceReference: string;
}

export interface Definition {
  term: string;
  definition: string;
  importance: 'Critical' | 'High' | 'Medium';
  sourceReference: string;
}

export interface CoreExplanation {
  id: string;
  heading: string;
  content: string;
  bullets?: string[];
  codeSnippet?: string;
  formula?: string;
  sourceReference: string;
}

export interface ExamEssential {
  tip: string;
  trapToAvoid: string;
  frequentlyTested: boolean;
  sourceReference: string;
}

export interface RevisionNotes {
  subject: string;
  title: string;
  overview: string;
  keyConcepts: KeyConcept[];
  definitions: Definition[];
  coreExplanations: CoreExplanation[];
  examEssentials: ExamEssential[];
  quickRecap: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctAnswer: number; // 0, 1, 2, 3
  explanation: string;
  topic: string;
  sourceReference: string;
}

export interface WeakTopicAnalysis {
  topic: string;
  missedCount: number;
  totalInTopic: number;
  diagnosis: string;
  targetSectionId: string; // matches CoreExplanation id or KeyConcept id for one-click deep link!
}

export interface TopicScore {
  topic: string;
  correct: number;
  total: number;
  percentage: number;
  status: 'mastered' | 'review_needed';
}

export interface QuizResult {
  score: number;
  totalQuestions: number;
  percentage: number;
  timeSpentSeconds: number;
  answers: Record<string, number>; // questionId -> selected option index
  markedForReview: string[]; // question IDs
  strongTopics: string[];
  weakTopics: WeakTopicAnalysis[];
  topicPerformance: TopicScore[];
  completedAt: string;
}

export interface StudySession {
  id: string;
  title: string;
  subject: string;
  fileName: string;
  fileSize: string;
  pageCount?: number;
  extractedContent: string;
  notes: RevisionNotes;
  quiz: QuizQuestion[];
  results?: QuizResult;
  createdAt: string;
}

export type AppView = 'dashboard' | 'upload' | 'processing' | 'workspace';
export type WorkspaceTab = 'notes' | 'quiz' | 'results';
