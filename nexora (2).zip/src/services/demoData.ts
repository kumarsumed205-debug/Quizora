import type { StudySession } from '../types';

export const DEMO_LECTURE_SESSION: StudySession = {
  id: 'session-demo-dsa-trees',
  title: 'Binary Search Trees & AVL Balancing',
  subject: 'Data Structures & Algorithms',
  fileName: 'Lecture_07_BST_and_AVL_Trees.pdf',
  fileSize: '2.4 MB',
  pageCount: 14,
  createdAt: 'Just now',
  extractedContent: `LECTURE 7: BINARY SEARCH TREES & SELF-BALANCING AVL TREES
Department of Computer Science & Engineering

Page 1: Introduction to Trees
A tree is a non-linear hierarchical data structure consisting of nodes connected by edges. In a binary tree, each node has at most two children, referred to as the left child and right child.
Search performance in an arbitrary binary tree is O(N) because we must inspect every node in the worst case.

Page 3: Binary Search Tree (BST) Property
A Binary Search Tree satisfies the fundamental ordering property:
For any given node X:
- Every key in the left subtree of X is strictly less than X.key (Left < Root)
- Every key in the right subtree of X is strictly greater than X.key (Right > Root)
- Both left and right subtrees must also be binary search trees.
Property Note: An IN-ORDER traversal (Left -> Root -> Right) of any valid BST visits the keys in strictly sorted ascending order.

Page 5: BST Operations & Complexities
1. Search: Compare target with current node. If target < current, go left; if target > current, go right.
2. Insertion: Follow search path until reaching a null pointer, insert new leaf node.
3. Deletion: Three distinct structural cases:
   - Case 1 (Leaf Node): Simply remove the node and update parent pointer to null.
   - Case 2 (Single Child): Splice out the node by linking parent directly to the single child.
   - Case 3 (Two Children): Replace node value with either its In-order Predecessor (max in left subtree) or In-order Successor (min in right subtree), then delete that replacement node from its original location.
Complexity: Average time complexity is O(log N). However, if elements are inserted in already sorted or reverse-sorted order, the tree degenerates into a linear linked list with height H = N, causing operations to degrade to O(N) worst-case!

Page 8: The Need for Self-Balancing: AVL Trees
Invented in 1962 by Adelson-Velsky and Landis (AVL), an AVL tree is a self-balancing binary search tree.
Height Definition: The height of an empty tree is -1; a leaf node has height 0.
Balance Factor (BF):
Balance Factor(node) = Height(node.left) - Height(node.right)
In an AVL tree, for EVERY node, the balance factor must satisfy:
BF in {-1, 0, +1}
If |BF| >= 2, the subtree is unbalanced and must be restored via rotation.

Page 11: AVL Rotations & Rebalancing
When a node becomes unbalanced (BF = +2 or -2) due to an insertion or deletion, we apply one of four rotation cases:
1. Left-Left (LL) Heavy: Fixed by a Single Right Rotation.
2. Right-Right (RR) Heavy: Fixed by a Single Left Rotation.
3. Left-Right (LR) Heavy: Fixed by a Double Rotation: Left rotation on left child, followed by Right rotation on unbalanced root.
4. Right-Left (RL) Heavy: Fixed by a Double Rotation: Right rotation on right child, followed by Left rotation on unbalanced root.
Guaranteed Height: The height of an AVL tree with N nodes is strictly bounded by 1.44 * log2(N). Consequently, Search, Insert, and Delete are guaranteed O(log N) worst-case time complexity.`,
  notes: {
    subject: 'Data Structures & Algorithms',
    title: 'Binary Search Trees & AVL Balancing',
    overview: 'This lecture covers the construction, traversal, and dynamic manipulation of Binary Search Trees (BST), analyzes the problem of tree skewing leading to O(N) degradation, and establishes the mathematical foundation of self-balancing AVL trees through balance factor invariants and rotations.',
    keyConcepts: [
      {
        id: 'concept-bst-property',
        title: 'BST Ordering Property',
        summary: 'For every node: all elements in the left subtree are smaller, and all elements in the right subtree are greater. In-order traversal always outputs elements in sorted order.',
        sourceReference: 'Lecture Page 3, Section 2'
      },
      {
        id: 'concept-bst-deletion',
        title: 'Three-Case BST Deletion',
        summary: 'Deleting a node requires distinct algorithms based on child count: leaf node removal, single-child splicing, or replacing a two-child node with its in-order predecessor/successor.',
        sourceReference: 'Lecture Page 5, Section 3.2'
      },
      {
        id: 'concept-avl-balance-factor',
        title: 'AVL Balance Factor Invariant',
        summary: 'Every node in an AVL tree maintains a balance factor BF = Height(Left) - Height(Right) strictly within {-1, 0, +1}. Height is strictly bounded to O(log N).',
        sourceReference: 'Lecture Page 8, Section 4.1'
      },
      {
        id: 'concept-avl-rotations',
        title: 'Single & Double Rotations',
        summary: 'Rebalancing requires constant O(1) pointer operations: LL/RR cases use single rotations, while zigzag LR/RL cases necessitate double rotations.',
        sourceReference: 'Lecture Page 11, Section 5'
      }
    ],
    definitions: [
      {
        term: 'Binary Search Tree (BST)',
        definition: 'A binary tree data structure where each node satisfies the key invariant: key(left subtree) < key(node) < key(right subtree).',
        importance: 'Critical',
        sourceReference: 'Lecture Page 3'
      },
      {
        term: 'Balance Factor (BF)',
        definition: 'The difference between the height of the left subtree and right subtree: BF(node) = Height(node.left) - Height(node.right).',
        importance: 'Critical',
        sourceReference: 'Lecture Page 8'
      },
      {
        term: 'In-order Successor',
        definition: 'The node with the smallest key strictly greater than the given node; found by taking one step right and following left child pointers to the bottom.',
        importance: 'High',
        sourceReference: 'Lecture Page 5'
      },
      {
        term: 'Degenerate Tree (Skewed)',
        definition: 'A BST where every internal node has only one child, causing the tree to degrade into a linear linked list with O(N) operation time.',
        importance: 'High',
        sourceReference: 'Lecture Page 6'
      }
    ],
    coreExplanations: [
      {
        id: 'sec-bst-mechanics',
        heading: 'BST Operations & Traversal Invariant',
        content: 'Binary Search Trees allow efficient binary searching when balanced. An in-order depth-first traversal (Left subtree, Root node, Right subtree) visits nodes in strictly ascending numerical order. Searching follows a simple divide-and-conquer path: compare target against node key, branching left if smaller or right if greater.',
        formula: 'T_{avg}(N) = O(\\log N), \\quad T_{worst}(N) = O(N)',
        bullets: [
          'In-order traversal: L -> Root -> R yields sorted sequence.',
          'Pre-order traversal: Root -> L -> R preserves tree structure for cloning/serialization.',
          'Post-order traversal: L -> R -> Root is ideal for bottom-up node deletion.'
        ],
        sourceReference: 'Lecture Page 3-5'
      },
      {
        id: 'sec-bst-deletion-cases',
        heading: 'Node Deletion Mechanics (The 3 Structural Cases)',
        content: 'Deleting a node in a BST requires preserving the BST property across three scenarios:',
        codeSnippet: `// Case 3 Deletion (Node with 2 Children):
Node* successor = findMin(targetNode->right);
targetNode->value = successor->value;
targetNode->right = deleteNode(targetNode->right, successor->value);`,
        bullets: [
          'Case 1: Node is a Leaf (0 children) -> Directly remove and set parent pointer to null.',
          'Case 2: Node has 1 Child -> Bypass the node; attach parent directly to the single child.',
          'Case 3: Node has 2 Children -> Locate in-order successor (minimum in right subtree) or predecessor (maximum in left subtree), overwrite target value, and recursively remove the successor.'
        ],
        sourceReference: 'Lecture Page 5, Case 3'
      },
      {
        id: 'sec-avl-balancing-rotations',
        heading: 'AVL Balancing Mechanics & Four Rotation Types',
        content: 'When an insertion or deletion pushes a node balance factor to +2 or -2, four rotational symmetries restore the height-balance invariant in O(1) time without violating BST order:',
        formula: 'BF(u) = \\text{height}(u.left) - \\text{height}(u.right) \\in \\{-1, 0, +1\\}',
        bullets: [
          'LL Heavy (Left-Left): Single Right Rotation on root.',
          'RR Heavy (Right-Right): Single Left Rotation on root.',
          'LR Heavy (Left-Right): Double Rotation -> Left rotation on child, then Right rotation on root.',
          'RL Heavy (Right-Left): Double Rotation -> Right rotation on child, then Left rotation on root.'
        ],
        sourceReference: 'Lecture Page 11, Section 5'
      }
    ],
    examEssentials: [
      {
        tip: 'In exam questions asking for a valid BST after in-order traversal, the list MUST be strictly monotonically increasing. If any duplicate or out-of-order element exists, it is invalid.',
        trapToAvoid: 'Never assume BST search is always O(log N). Always explicitly mention that worst-case is O(N) when the input is sorted, which is the exact motivation for AVL trees.',
        frequentlyTested: true,
        sourceReference: 'Lecture Page 6, Exam Note'
      },
      {
        tip: 'For Double Rotations (LR or RL), remember the direction of the first rotation: rotate the CHILD in the opposite direction first, then rotate the ROOT into balance.',
        trapToAvoid: 'Do not confuse Balance Factor sign conventions. If BF = Left - Right, +2 means left-heavy, requiring right rotation.',
        frequentlyTested: true,
        sourceReference: 'Lecture Page 12'
      }
    ],
    quickRecap: [
      'BST Property: Left subtree < Node < Right subtree.',
      'In-order traversal of BST produces strictly sorted ascending order.',
      'Worst-case BST operations degrade to O(N) when input is sorted.',
      'AVL tree guarantees O(log N) worst-case by enforcing |BF| <= 1 at every node.',
      'Balance Factor = Height(Left) - Height(Right).',
      'Unbalanced states are restored using 4 rotation types: LL, RR, LR, RL.'
    ]
  },
  quiz: [
    {
      id: 'q1',
      question: 'Which tree traversal algorithm applied to a valid Binary Search Tree is guaranteed to visit all keys in strictly ascending sorted order?',
      options: [
        'Pre-order Traversal (Root, Left, Right)',
        'In-order Traversal (Left, Root, Right)',
        'Post-order Traversal (Left, Right, Root)',
        'Level-order Breadth-First Traversal'
      ],
      correctAnswer: 1,
      explanation: 'By definition of the BST ordering invariant (Left < Root < Right), an in-order traversal recursively visits all keys smaller than the root, then the root, then all keys larger than the root, generating a strictly sorted ascending sequence.',
      topic: 'BST Traversal & Invariants',
      sourceReference: 'Lecture Page 3, Section 2'
    },
    {
      id: 'q2',
      question: 'What is the WORST-CASE time complexity of searching for a value in an ordinary (unbalanced) Binary Search Tree containing N nodes?',
      options: [
        'O(log N)',
        'O(N log N)',
        'O(N)',
        'O(1)'
      ],
      correctAnswer: 2,
      explanation: 'When keys are inserted in strictly sorted or reverse-sorted order, an ordinary BST degenerates into a linear linked list where each node has only one child. The tree height becomes H = N, resulting in O(N) worst-case search.',
      topic: 'Time Complexity & Skewing',
      sourceReference: 'Lecture Page 5 & 6'
    },
    {
      id: 'q3',
      question: 'When deleting a node that possesses TWO children in a Binary Search Tree, what is the standard procedure to preserve the BST invariant?',
      options: [
        'Delete the node and promote its left child directly to its place, discarding the right child.',
        'Replace the node value with either its In-order Predecessor or In-order Successor, then delete that replacement node.',
        'Rotate the tree to convert the target node into a leaf before deleting.',
        'Split the tree into two disjoint forests and re-insert all keys.'
      ],
      correctAnswer: 1,
      explanation: 'In Case 3 deletion (two children), the node value is replaced by its in-order predecessor (maximum value in left subtree) or in-order successor (minimum value in right subtree), and then that leaf/single-child node is removed.',
      topic: 'BST Deletion Mechanics',
      sourceReference: 'Lecture Page 5, Case 3'
    },
    {
      id: 'q4',
      question: 'In an AVL tree, what are the permissible values for the Balance Factor (defined as Height(Left) - Height(Right)) of any given node?',
      options: [
        'Only 0',
        '{-1, 0, +1}',
        '{-2, -1, 0, +1, +2}',
        'Any non-negative integer'
      ],
      correctAnswer: 1,
      explanation: 'An AVL tree strictly requires that the height difference between the left and right subtrees of EVERY node does not exceed 1. Thus, the allowed balance factors are exclusively {-1, 0, +1}.',
      topic: 'AVL Balance Factor Invariant',
      sourceReference: 'Lecture Page 8, Section 4.1'
    },
    {
      id: 'q5',
      question: 'Suppose a node in an AVL tree becomes unbalanced with BF = +2 due to an insertion into the RIGHT subtree of its LEFT child (Left-Right case). What rotation sequence is required?',
      options: [
        'A single Right Rotation on the unbalanced node',
        'A single Left Rotation on the unbalanced node',
        'A Left Rotation on the left child, followed by a Right Rotation on the unbalanced node',
        'A Right Rotation on the left child, followed by a Left Rotation on the unbalanced node'
      ],
      correctAnswer: 2,
      explanation: 'A Left-Right (LR) imbalance is a zigzag condition. It requires a double rotation: first a Left rotation on the left child to straighten the subtree, followed by a Right rotation on the unbalanced parent node.',
      topic: 'AVL Rotations & Balancing',
      sourceReference: 'Lecture Page 11, Section 5'
    },
    {
      id: 'q6',
      question: 'What is the maximum height of an AVL tree containing N nodes, and what does this guarantee for search operations?',
      options: [
        'Height is O(N), guaranteeing linear search time',
        'Height is strictly bounded by ~1.44 log2(N), guaranteeing O(log N) worst-case search',
        'Height is strictly bounded by log10(N), guaranteeing O(1) search',
        'Height is unbounded, but average search remains O(1)'
      ],
      correctAnswer: 1,
      explanation: 'Mathematical analysis of Fibonacci trees (worst-case AVL trees) proves that the height is strictly bounded by approximately 1.44 * log2(N). This mathematical bound guarantees O(log N) operations in the worst case.',
      topic: 'AVL Height Bounds & Guarantees',
      sourceReference: 'Lecture Page 11'
    },
    {
      id: 'q7',
      question: 'In a valid Binary Search Tree, where can you always find the minimum key in the tree?',
      options: [
        'At the root node',
        'By traversing all right child pointers until a leaf is reached',
        'By continuously following left child pointers from the root until reaching a node with no left child',
        'At the deepest level on the rightmost branch'
      ],
      correctAnswer: 2,
      explanation: 'Because every node in a left subtree must have a key strictly less than its parent, the minimum key in any non-empty BST is always found by starting at the root and continuously following left child pointers until no left child exists.',
      topic: 'BST Traversal & Invariants',
      sourceReference: 'Lecture Page 3'
    }
  ]
};

export const INITIAL_RECENT_SESSIONS: StudySession[] = [
  {
    id: 'session-recent-dsa',
    title: 'Binary Search Trees & AVL Balancing',
    subject: 'Data Structures',
    fileName: 'Lecture_07_BST_and_AVL_Trees.pdf',
    fileSize: '2.4 MB',
    pageCount: 14,
    createdAt: '2 hours ago',
    extractedContent: DEMO_LECTURE_SESSION.extractedContent,
    notes: DEMO_LECTURE_SESSION.notes,
    quiz: DEMO_LECTURE_SESSION.quiz,
    results: {
      score: 5,
      totalQuestions: 7,
      percentage: 71,
      timeSpentSeconds: 145,
      answers: {
        q1: 1, // Correct
        q2: 2, // Correct
        q3: 0, // Missed (selected 0 instead of 1)
        q4: 1, // Correct
        q5: 0, // Missed (selected single rotation instead of double)
        q6: 1, // Correct
        q7: 2  // Correct
      },
      markedForReview: ['q3'],
      strongTopics: ['BST Traversal & Invariants', 'AVL Balance Factor Invariant', 'Time Complexity & Skewing'],
      weakTopics: [
        {
          topic: 'AVL Rotations & Balancing',
          missedCount: 1,
          totalInTopic: 1,
          diagnosis: 'Missed zigzag Left-Right rotation requirements; remember LR requires a double rotation.',
          targetSectionId: 'sec-avl-balancing-rotations'
        },
        {
          topic: 'BST Deletion Mechanics',
          missedCount: 1,
          totalInTopic: 1,
          diagnosis: 'Struggled with Case 3 (two children) deletion replacement with predecessor/successor.',
          targetSectionId: 'sec-bst-deletion-cases'
        }
      ],
      topicPerformance: [
        { topic: 'BST Traversal & Invariants', correct: 2, total: 2, percentage: 100, status: 'mastered' },
        { topic: 'Time Complexity & Skewing', correct: 1, total: 1, percentage: 100, status: 'mastered' },
        { topic: 'AVL Balance Factor Invariant', correct: 1, total: 1, percentage: 100, status: 'mastered' },
        { topic: 'AVL Height Bounds & Guarantees', correct: 1, total: 1, percentage: 100, status: 'mastered' },
        { topic: 'AVL Rotations & Balancing', correct: 0, total: 1, percentage: 0, status: 'review_needed' },
        { topic: 'BST Deletion Mechanics', correct: 0, total: 1, percentage: 0, status: 'review_needed' }
      ],
      completedAt: '2 hours ago'
    }
  },
  {
    id: 'session-recent-digital-logic',
    title: 'Finite State Machines & Sequential Circuits',
    subject: 'Digital Logic',
    fileName: 'EE201_Module4_Sequential_FSM.pdf',
    fileSize: '3.1 MB',
    pageCount: 18,
    createdAt: 'Yesterday',
    extractedContent: 'Digital Logic FSM Lecture content...',
    notes: {
      subject: 'Digital Logic',
      title: 'Finite State Machines & Sequential Circuits',
      overview: 'Comprehensive study of Mealy and Moore machine architectures, state transition diagrams, excitation tables, and flip-flop timing constraints.',
      keyConcepts: [
        { id: 'dl-1', title: 'Mealy vs Moore Machines', summary: 'Moore outputs depend solely on current state; Mealy outputs depend on current state and immediate inputs.', sourceReference: 'Slide 4' },
        { id: 'dl-2', title: 'State Minimization', summary: 'Equivalent state reduction using implication tables to minimize physical flip-flop count.', sourceReference: 'Slide 9' }
      ],
      definitions: [
        { term: 'Setup Time (t_su)', definition: 'Minimum time data must remain stable before active clock edge.', importance: 'Critical', sourceReference: 'Slide 14' }
      ],
      coreExplanations: [
        { id: 'dl-sec-1', heading: 'State Transition Equations', content: 'Derivation of D and JK flip-flop excitation equations from state tables.', sourceReference: 'Slide 7' }
      ],
      examEssentials: [
        { tip: 'Always verify if output changes asynchronously on input glitch in Mealy models.', trapToAvoid: 'Forgetting clock skew calculations in setup/hold slack.', frequentlyTested: true, sourceReference: 'Slide 16' }
      ],
      quickRecap: ['Moore: Output = f(State)', 'Mealy: Output = f(State, Input)', 'Setup/Hold violations cause metastability.']
    },
    quiz: [],
    results: {
      score: 9,
      totalQuestions: 10,
      percentage: 92,
      timeSpentSeconds: 198,
      answers: {},
      markedForReview: [],
      strongTopics: ['FSM Architectures', 'Excitation Tables', 'Timing & Clock Skew'],
      weakTopics: [],
      topicPerformance: [
        { topic: 'FSM Architectures', correct: 5, total: 5, percentage: 100, status: 'mastered' },
        { topic: 'Timing & Clock Skew', correct: 4, total: 5, percentage: 80, status: 'mastered' }
      ],
      completedAt: 'Yesterday'
    }
  },
  {
    id: 'session-recent-os',
    title: 'Virtual Memory & Page Replacement',
    subject: 'Operating Systems',
    fileName: 'CS304_OS_VirtualMemory_Paging.pdf',
    fileSize: '1.8 MB',
    pageCount: 12,
    createdAt: '3 days ago',
    extractedContent: 'Operating Systems Virtual Memory and TLB notes...',
    notes: {
      subject: 'Operating Systems',
      title: 'Virtual Memory & Page Replacement',
      overview: 'Analysis of paging architectures, Translation Lookaside Buffers (TLB), Belady’s anomaly, and page replacement policies (FIFO, LRU, Optimal).',
      keyConcepts: [
        { id: 'os-1', title: 'Page Fault Handling', summary: 'Trap to OS, disk seek for missing page, frame allocation, and page table update.', sourceReference: 'Page 5' },
        { id: 'os-2', title: 'Belady’s Anomaly', summary: 'Phenomenon where increasing frame count leads to MORE page faults under FIFO.', sourceReference: 'Page 8' }
      ],
      definitions: [
        { term: 'Translation Lookaside Buffer (TLB)', definition: 'High-speed associative hardware cache for virtual-to-physical address translations.', importance: 'Critical', sourceReference: 'Page 3' }
      ],
      coreExplanations: [
        { id: 'os-sec-1', heading: 'Effective Memory Access Time (EMAT)', content: 'EMAT = Hit_Rate * (TLB_time + Memory_time) + (1 - Hit_Rate) * (TLB_time + 2 * Memory_time)', sourceReference: 'Page 6' }
      ],
      examEssentials: [
        { tip: 'LRU and Optimal algorithms belong to the stack algorithm class and never suffer from Belady’s anomaly.', trapToAvoid: 'Counting initial compulsory misses as page replacement algorithm faults.', frequentlyTested: true, sourceReference: 'Page 9' }
      ],
      quickRecap: ['TLB dramatically reduces average memory access time.', 'FIFO can suffer from Beladys anomaly.', 'LRU approximates Optimal replacement.']
    },
    quiz: [],
    results: {
      score: 5,
      totalQuestions: 8,
      percentage: 64,
      timeSpentSeconds: 165,
      answers: {},
      markedForReview: [],
      strongTopics: ['Paging Fundamentals'],
      weakTopics: [
        {
          topic: 'Page Replacement Algorithms & Belady’s Anomaly',
          missedCount: 2,
          totalInTopic: 3,
          diagnosis: 'Confused FIFO replacement traces with LRU stack properties.',
          targetSectionId: 'os-sec-1'
        }
      ],
      topicPerformance: [
        { topic: 'Paging Fundamentals', correct: 4, total: 4, percentage: 100, status: 'mastered' },
        { topic: 'Page Replacement Algorithms', correct: 1, total: 4, percentage: 25, status: 'review_needed' }
      ],
      completedAt: '3 days ago'
    }
  }
];
