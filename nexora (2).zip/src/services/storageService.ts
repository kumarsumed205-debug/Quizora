import type { StudySession, QuizResult } from '../types';
import { INITIAL_RECENT_SESSIONS, DEMO_LECTURE_SESSION } from './demoData';

const STORAGE_KEY = 'nexora_study_sessions_v1';

export function loadSessions(): StudySession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed with initial realistic sessions
      saveSessions(INITIAL_RECENT_SESSIONS);
      return INITIAL_RECENT_SESSIONS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_RECENT_SESSIONS;
  } catch (err) {
    console.warn('Error reading from localStorage, using initial sessions:', err);
    return INITIAL_RECENT_SESSIONS;
  }
}

export function saveSessions(sessions: StudySession[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  } catch (err) {
    console.error('Failed to save sessions to localStorage:', err);
  }
}

export function saveSession(newSession: StudySession): StudySession[] {
  const existing = loadSessions();
  const filtered = existing.filter((s) => s.id !== newSession.id);
  const updated = [newSession, ...filtered];
  saveSessions(updated);
  return updated;
}

export function deleteSession(id: string): StudySession[] {
  const existing = loadSessions();
  const updated = existing.filter((s) => s.id !== id);
  saveSessions(updated);
  return updated;
}

export function updateSessionQuizResults(
  sessionId: string,
  results: QuizResult
): { updatedSessions: StudySession[]; updatedSession: StudySession | null } {
  const existing = loadSessions();
  let foundSession: StudySession | null = null;

  const updated = existing.map((s) => {
    if (s.id === sessionId) {
      foundSession = { ...s, results };
      return foundSession;
    }
    return s;
  });

  if (foundSession) {
    saveSessions(updated);
  }

  return { updatedSessions: updated, updatedSession: foundSession };
}

export function getDemoSession(): StudySession {
  // Return a clean clone of the demo session
  return JSON.parse(JSON.stringify(DEMO_LECTURE_SESSION));
}
