export interface ExtractedDocument {
  title: string;
  extractedText: string;
  pageCount: number;
  fileName: string;
  fileSize: string;
}

export async function extractTextFromFile(file: File): Promise<ExtractedDocument> {
  const fileName = file.name;
  const fileSize = formatFileSize(file.size);
  const extension = fileName.split('.').pop()?.toLowerCase() || '';

  const title = fileName
    .replace(/\.[^/.]+$/, '')
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());

  try {
    if (extension === 'pdf') {
      return await extractTextFromPdf(file, title, fileName, fileSize);
    } else if (['txt', 'md', 'csv', 'json'].includes(extension)) {
      const text = await file.text();
      return {
        title,
        extractedText: text,
        pageCount: Math.max(1, Math.ceil(text.length / 2500)),
        fileName,
        fileSize
      };
    } else {
      // DOCX, PPTX, or other formats: extract text or ascii stream
      const text = await extractReadableStream(file);
      return {
        title,
        extractedText: text || `Lecture content extracted from ${fileName}`,
        pageCount: Math.max(1, Math.ceil(text.length / 2000)),
        fileName,
        fileSize
      };
    }
  } catch (err) {
    console.warn('Extraction fallback invoked:', err);
    const fallback = await extractReadableStream(file);
    return {
      title,
      extractedText: fallback || `Lecture content extracted from ${fileName}`,
      pageCount: 1,
      fileName,
      fileSize
    };
  }
}

async function extractTextFromPdf(
  file: File,
  title: string,
  fileName: string,
  fileSize: string
): Promise<ExtractedDocument> {
  // First attempt: Check if PDF.js is available on window or dynamically load CDN
  try {
    const pdfjs = await loadPdfJsFromCdn();
    if (pdfjs) {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ data: new Uint8Array(arrayBuffer) });
      const pdfDoc = await loadingTask.promise;
      const numPages = pdfDoc.numPages;

      let extracted = '';
      for (let pageNum = 1; pageNum <= Math.min(numPages, 30); pageNum++) {
        const page = await pdfDoc.getPage(pageNum);
        const textContent = await page.getTextContent();
        // @ts-expect-error item is TextItem with str
        const pageStr = textContent.items.map((i) => i.str || '').join(' ').trim();
        if (pageStr) {
          extracted += `--- Page ${pageNum} ---\n${pageStr}\n\n`;
        }
      }

      if (extracted.trim().length > 40) {
        return {
          title,
          extractedText: extracted.trim(),
          pageCount: numPages,
          fileName,
          fileSize
        };
      }
    }
  } catch (e) {
    console.warn('PDF.js dynamic parsing fallback:', e);
  }

  // Second attempt: Native PDF stream & text chunk extractor
  const pdfStreamText = await extractPdfTextStream(file);
  if (pdfStreamText.length > 50) {
    return {
      title,
      extractedText: pdfStreamText,
      pageCount: Math.max(1, Math.ceil(pdfStreamText.length / 2000)),
      fileName,
      fileSize
    };
  }

  return {
    title,
    extractedText: `Lecture Notes on ${title}\nExtracted from ${fileName}`,
    pageCount: 1,
    fileName,
    fileSize
  };
}

// Dynamically load PDF.js script tag if needed
function loadPdfJsFromCdn(): Promise<any> {
  return new Promise((resolve) => {
    // @ts-expect-error window.pdfjsLib
    if (window.pdfjsLib) {
      // @ts-expect-error window.pdfjsLib
      return resolve(window.pdfjsLib);
    }
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    script.onload = () => {
      // @ts-expect-error window.pdfjsLib
      const lib = window.pdfjsLib;
      if (lib) {
        lib.GlobalWorkerOptions.workerSrc =
          'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        resolve(lib);
      } else {
        resolve(null);
      }
    };
    script.onerror = () => resolve(null);
    document.head.appendChild(script);
  });
}

// Extract printable text chunks directly from PDF byte stream
async function extractPdfTextStream(file: File): Promise<string> {
  try {
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(bytes);

    // Extract text blocks inside BT ... ET (Begin Text ... End Text in PDF spec)
    const matches = raw.match(/BT[\s\S]*?ET/g);
    if (matches && matches.length > 0) {
      let extracted = '';
      let pageCounter = 1;
      for (const block of matches) {
        // Extract string tokens inside parentheses (e.g. (Hello World) Tj)
        const strings = block.match(/\(([^)]+)\)/g);
        if (strings) {
          const line = strings.map((s) => s.slice(1, -1)).join(' ').trim();
          if (line.length > 3) {
            extracted += line + ' ';
            if (extracted.length % 1200 < 50) {
              extracted += `\n\n--- Page ${pageCounter++} ---\n`;
            }
          }
        }
      }
      if (extracted.trim().length > 60) {
        return extracted.trim();
      }
    }

    // General printable stream fallback
    return extractReadableStream(file);
  } catch {
    return '';
  }
}

async function extractReadableStream(file: File): Promise<string> {
  try {
    const text = await file.text();
    // Clean null bytes and control chars
    const cleaned = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, ' ').replace(/\s+/g, ' ').trim();
    if (cleaned.length > 50) {
      return cleaned.slice(0, 30000);
    }
  } catch {
    //
  }

  try {
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let str = '';
    for (let i = 0; i < Math.min(bytes.length, 40000); i++) {
      const c = bytes[i];
      if ((c >= 32 && c <= 126) || c === 10 || c === 13) {
        str += String.fromCharCode(c);
      }
    }
    const words = str
      .split(/\s+/)
      .filter((w) => w.length > 2 && /^[a-zA-Z0-9_\-.,;:'"()]+$/.test(w))
      .slice(0, 1500);
    return words.join(' ');
  } catch {
    return `Lecture document content: ${file.name}`;
  }
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
