import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  BookOpen,
  Clock,
  Printer,
  ChevronDown,
  Sparkles,
  Target,
  FileCheck
} from 'lucide-react';
import type { QuizQuestion, QuizResult } from '../types';

interface QuizResultsViewProps {
  results: QuizResult;
  quiz: QuizQuestion[];
  lectureTitle: string;
  onRetakeQuiz: () => void;
  onNavigateToSection: (sectionId: string) => void;
  onReviewAllNotes: () => void;
}

export const QuizResultsView: React.FC<QuizResultsViewProps> = ({
  results,
  quiz,
  lectureTitle,
  onRetakeQuiz,
  onNavigateToSection,
  onReviewAllNotes
}) => {
  const { score, totalQuestions, percentage, timeSpentSeconds, weakTopics, topicPerformance, answers } =
    results;

  const isHigh = percentage >= 80;
  const isMedium = percentage >= 60 && percentage < 80;

  // Trigger celebration confetti for good scores
  useEffect(() => {
    if (percentage >= 70) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // Safe fail
      }
    }
  }, [percentage]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      {/* Top Banner & Main Score Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-10 space-y-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-100">
          {/* Score gauge / badge */}
          <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
            <div
              className={`w-28 h-28 rounded-3xl flex flex-col items-center justify-center font-extrabold shadow-inner border-2 ${
                isHigh
                  ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                  : isMedium
                  ? 'bg-amber-50 text-amber-600 border-amber-200'
                  : 'bg-rose-50 text-rose-600 border-rose-200'
              }`}
            >
              <span className="text-3xl font-extrabold">{percentage}%</span>
              <span className="text-xs uppercase tracking-wider font-semibold opacity-80">
                Score
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-[11px] font-semibold text-slate-600">
                <FileCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span>Quiz Evaluation Completed</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {isHigh
                  ? 'Outstanding Comprehension!'
                  : isMedium
                  ? 'Good Progress — Targeted Revision Recommended'
                  : 'Foundational Revision Needed'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500">
                You answered <strong className="text-slate-900">{score}</strong> out of{' '}
                <strong className="text-slate-900">{totalQuestions}</strong> questions correctly in{' '}
                <strong className="text-slate-900">{formatTimer(timeSpentSeconds)}</strong>.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-3 flex-shrink-0 no-print">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Results</span>
            </button>
            <button
              onClick={onRetakeQuiz}
              className="flex items-center gap-1.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake Quiz</span>
            </button>
          </div>
        </div>

        {/* Closed Learning Loop Section: AI WEAK-TOPIC ANALYSIS */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-rose-50 rounded-lg text-rose-600 border border-rose-100">
                <Target className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Revise These Next (Closed Learning Loop)
                </h3>
                <p className="text-xs text-slate-500">
                  Targeted diagnostics pinpointing exactly what concepts to review in your notes
                </p>
              </div>
            </div>
            <button
              onClick={onReviewAllNotes}
              className="no-print text-xs font-semibold text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-1"
            >
              <span>View All Notes</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {weakTopics.length === 0 ? (
            <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-emerald-800 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 flex-shrink-0" />
              <div className="text-xs">
                <strong className="text-sm font-bold block">Flawless Concept Mastery!</strong>
                You demonstrated solid proficiency across all tested lecture topics.
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {weakTopics.map((item, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-gradient-to-br from-rose-50/70 to-amber-50/40 border border-rose-200/90 shadow-2xs space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-rose-500" />
                        <span>{item.topic}</span>
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                        {item.missedCount} Missed
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.diagnosis}
                    </p>
                  </div>

                  {/* Crucial Action: Review Topic deep link */}
                  <div className="pt-2 no-print">
                    <button
                      onClick={() => onNavigateToSection(item.targetSectionId)}
                      className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white hover:bg-rose-50/80 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 shadow-xs transition-all hover:scale-[1.01]"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-rose-600" />
                      <span>Review Topic in Revision Notes</span>
                      <ArrowRight className="w-3.5 h-3.5 text-rose-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Topic-Level Breakdown Cards */}
        <div className="pt-4 border-t border-slate-100 space-y-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-600" />
            <span>Topic-Level Breakdown</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {topicPerformance.map((tp, idx) => {
              const isMastered = tp.status === 'mastered';
              return (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 truncate max-w-[150px]">
                      {tp.topic}
                    </span>
                    <span
                      className={`text-[11px] font-bold ${
                        isMastered ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {tp.correct}/{tp.total} ({tp.percentage}%)
                    </span>
                  </div>

                  <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        isMastered ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${tp.percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Comprehensive Question-by-Question Review */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-10 space-y-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Detailed Question & Answer Review
          </h2>
          <p className="text-xs text-slate-500">
            Compare your chosen responses against the grounded source material
          </p>
        </div>

        <div className="space-y-4">
          {quiz.map((q, idx) => {
            const userChoice = answers[q.id];
            const isCorrect = userChoice === q.correctAnswer;
            const optionLetters = ['A', 'B', 'C', 'D'];

            return (
              <div
                key={q.id}
                className={`p-6 rounded-2xl border-2 space-y-4 ${
                  isCorrect
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : 'border-rose-200 bg-rose-50/20'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                        isCorrect ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="font-bold text-xs uppercase tracking-wider text-slate-700">
                      {q.topic}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {q.sourceReference}
                  </span>
                </div>

                {/* Question */}
                <h4 className="font-bold text-slate-900 text-sm leading-snug">
                  {q.question}
                </h4>

                {/* Options Review */}
                <div className="space-y-2 text-xs">
                  {q.options.map((opt, optIdx) => {
                    const isUserSelected = userChoice === optIdx;
                    const isRightAnswer = q.correctAnswer === optIdx;

                    let badgeClass = 'bg-slate-50 text-slate-700 border-slate-200';
                    if (isRightAnswer) {
                      badgeClass = 'bg-emerald-100 text-emerald-900 border-emerald-300 font-semibold';
                    } else if (isUserSelected && !isRightAnswer) {
                      badgeClass = 'bg-rose-100 text-rose-900 border-rose-300 line-through';
                    }

                    return (
                      <div
                        key={optIdx}
                        className={`flex items-start gap-3 p-2.5 rounded-xl border ${badgeClass}`}
                      >
                        <span className="font-bold w-5 text-center flex-shrink-0">
                          {optionLetters[optIdx]}.
                        </span>
                        <span className="flex-1 leading-relaxed">{opt}</span>
                        {isRightAnswer && (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-200 px-1.5 py-0.5 rounded flex-shrink-0">
                            Correct
                          </span>
                        )}
                        {isUserSelected && !isRightAnswer && (
                          <span className="text-[10px] font-bold text-rose-700 bg-rose-200 px-1.5 py-0.5 rounded flex-shrink-0">
                            Your Choice
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Grounded Explanation */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-700 space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Academic Explanation & Source Citation</span>
                  </div>
                  <p className="leading-relaxed text-slate-600">{q.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
