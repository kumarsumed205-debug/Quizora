import React, { useState, useEffect } from 'react';
import {
  HelpCircle,
  Flag,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Send,
  BookOpen,
  Clock
} from 'lucide-react';
import type { QuizQuestion, QuizResult, WeakTopicAnalysis, TopicScore } from '../types';

interface PracticeQuizViewProps {
  quiz: QuizQuestion[];
  lectureTitle: string;
  onSubmitQuiz: (result: QuizResult) => void;
  onBackToNotes: () => void;
}

export const PracticeQuizView: React.FC<PracticeQuizViewProps> = ({
  quiz,
  lectureTitle,
  onSubmitQuiz,
  onBackToNotes
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [markedForReview, setMarkedForReview] = useState<string[]>([]);
  const [startTime] = useState<number>(Date.now());
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);

  // Timer ticker
  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [startTime]);

  const currentQuestion = quiz[currentIndex];
  const total = quiz.length;
  const answeredCount = Object.keys(selectedAnswers).length;
  const isCurrentMarked = markedForReview.includes(currentQuestion.id);

  const handleSelectOption = (optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optionIndex
    }));
  };

  const handleToggleMark = () => {
    setMarkedForReview((prev) =>
      prev.includes(currentQuestion.id)
        ? prev.filter((id) => id !== currentQuestion.id)
        : [...prev, currentQuestion.id]
    );
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < total - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handleFinalSubmit = () => {
    // Calculate score, topic breakdown and weak topics
    let correctCount = 0;
    const topicStats: Record<string, { correct: number; total: number; missedDiagnoses: string[] }> = {};

    quiz.forEach((q) => {
      const selected = selectedAnswers[q.id];
      const isCorrect = selected === q.correctAnswer;

      if (!topicStats[q.topic]) {
        topicStats[q.topic] = { correct: 0, total: 0, missedDiagnoses: [] };
      }
      topicStats[q.topic].total += 1;

      if (isCorrect) {
        correctCount += 1;
        topicStats[q.topic].correct += 1;
      } else {
        topicStats[q.topic].missedDiagnoses.push(q.explanation);
      }
    });

    const percentage = Math.round((correctCount / total) * 100);

    const strongTopics: string[] = [];
    const weakTopics: WeakTopicAnalysis[] = [];
    const topicPerformance: TopicScore[] = [];

    Object.entries(topicStats).forEach(([topic, stats]) => {
      const topicPct = Math.round((stats.correct / stats.total) * 100);
      const isMastered = topicPct >= 70;

      topicPerformance.push({
        topic,
        correct: stats.correct,
        total: stats.total,
        percentage: topicPct,
        status: isMastered ? 'mastered' : 'review_needed'
      });

      if (isMastered) {
        strongTopics.push(topic);
      } else {
        // Find diagnosis
        const missed = stats.total - stats.correct;
        weakTopics.push({
          topic,
          missedCount: missed,
          totalInTopic: stats.total,
          diagnosis:
            stats.missedDiagnoses[0] ||
            `Missed ${missed} question${missed > 1 ? 's' : ''} in this section.`,
          targetSectionId: 'sec-foundational-theory'
        });
      }
    });

    const result: QuizResult = {
      score: correctCount,
      totalQuestions: total,
      percentage,
      timeSpentSeconds: elapsedSeconds,
      answers: selectedAnswers,
      markedForReview,
      strongTopics,
      weakTopics,
      topicPerformance,
      completedAt: 'Just now'
    };

    onSubmitQuiz(result);
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6 animate-fadeIn">
      {/* Quiz Navigation Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToNotes}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
            title="Return to Revision Notes"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Practice Quiz
            </span>
            <h2 className="text-sm sm:text-base font-bold text-slate-900 truncate max-w-sm">
              {lectureTitle}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-mono font-semibold text-slate-700">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>{formatTimer(elapsedSeconds)}</span>
          </div>

          <button
            onClick={() => setShowConfirmModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Submit Quiz</span>
          </button>
        </div>
      </div>

      {/* Progress & Question Index Pills */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-600 font-semibold">
          <span>
            Question {currentIndex + 1} of {total}
          </span>
          <span>
            {answeredCount} of {total} Answered
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
          <div
            className="h-full bg-indigo-600 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / total) * 100}%` }}
          />
        </div>

        {/* Question Selector Pills */}
        <div className="flex flex-wrap gap-2 pt-1">
          {quiz.map((q, idx) => {
            const isAnswered = selectedAnswers[q.id] !== undefined;
            const isMarked = markedForReview.includes(q.id);
            const isCurrent = idx === currentIndex;

            return (
              <button
                key={q.id}
                onClick={() => setCurrentIndex(idx)}
                className={`relative w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                  isCurrent
                    ? 'ring-2 ring-indigo-600 ring-offset-1 bg-indigo-600 text-white'
                    : isAnswered
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {idx + 1}
                {isMarked && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Question Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        {/* Question Header & Meta */}
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-slate-100 text-slate-700">
              {currentQuestion.topic}
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {currentQuestion.sourceReference}
            </span>
          </div>

          {/* Mark for review toggle */}
          <button
            onClick={handleToggleMark}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              isCurrentMarked
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            <Flag className={`w-3.5 h-3.5 ${isCurrentMarked ? 'fill-amber-600 text-amber-600' : ''}`} />
            <span>{isCurrentMarked ? 'Marked' : 'Mark for Review'}</span>
          </button>
        </div>

        {/* Question Text */}
        <div className="space-y-2">
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
            {currentQuestion.question}
          </h3>
          <p className="text-xs text-slate-400">Select the single best answer below:</p>
        </div>

        {/* Options List */}
        <div className="space-y-3">
          {currentQuestion.options.map((opt, optIdx) => {
            const isSelected = selectedAnswers[currentQuestion.id] === optIdx;
            const optionLetters = ['A', 'B', 'C', 'D'];

            return (
              <div
                key={optIdx}
                onClick={() => handleSelectOption(optIdx)}
                className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/50 shadow-xs scale-[1.005]'
                    : 'border-slate-200 hover:border-indigo-200 hover:bg-slate-50/50'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 transition-colors ${
                    isSelected
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {optionLetters[optIdx]}
                </div>
                <div className="pt-0.5 text-xs sm:text-sm text-slate-800 font-medium leading-relaxed">
                  {opt}
                </div>
              </div>
            );
          })}
        </div>

        {/* Question Navigation Controls */}
        <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
              currentIndex === 0
                ? 'opacity-40 cursor-not-allowed text-slate-400 bg-slate-100'
                : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>

          {currentIndex < total - 1 ? (
            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => setShowConfirmModal(true)}
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-all"
            >
              <span>Complete Quiz</span>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Submission Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                <HelpCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                Ready to submit your quiz?
              </h3>
              <p className="text-xs text-slate-500">
                We will calculate your score and identify specific topics to revise.
              </p>
            </div>

            {/* Answered / Marked Summary */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between font-medium text-slate-700">
                <span>Total Questions:</span>
                <span className="font-bold">{total}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Answered Questions:</span>
                <span className="font-bold text-indigo-600">{answeredCount}</span>
              </div>
              {total - answeredCount > 0 && (
                <div className="flex items-center gap-1.5 text-rose-600 font-semibold pt-1">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{total - answeredCount} question(s) left unanswered!</span>
                </div>
              )}
              {markedForReview.length > 0 && (
                <div className="flex items-center gap-1.5 text-amber-700 font-medium">
                  <Flag className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                  <span>{markedForReview.length} question(s) marked for review.</span>
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Keep Reviewing
              </button>
              <button
                onClick={() => {
                  setShowConfirmModal(false);
                  handleFinalSubmit();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all"
              >
                Submit Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
