import React, { useState } from 'react';
import {
  BookOpen,
  HelpCircle,
  Sparkles,
  Bookmark,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  FileText,
  Printer,
  ExternalLink,
  ChevronRight,
  Code,
  Hash
} from 'lucide-react';
import type { RevisionNotes } from '../types';

interface RevisionNotesViewProps {
  notes: RevisionNotes;
  pageCount?: number;
  onStartQuiz: () => void;
  onOpenSourceInspector: () => void;
}

export const RevisionNotesView: React.FC<RevisionNotesViewProps> = ({
  notes,
  pageCount = 1,
  onStartQuiz,
  onOpenSourceInspector
}) => {
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [highlightedSource, setHighlightedSource] = useState<string | null>(null);

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Banner: Quiz Prompt */}
      <div className="no-print mb-8 p-6 rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white shadow-lg border border-indigo-700/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 text-xs font-semibold text-indigo-200">
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>AI Revision Notes Ready</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight">
            Review your condensed notes, then test your retention.
          </h2>
          <p className="text-xs text-slate-300">
            These notes were synthesized from your lecture slides. Once reviewed, test yourself with 7 grounded questions.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-shrink-0">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-white/10 hover:bg-white/15 rounded-xl border border-white/20 transition-all"
            title="Export or Print cheat-sheet"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export / Print</span>
          </button>

          <button
            onClick={onStartQuiz}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-indigo-900 bg-white hover:bg-indigo-50 rounded-xl shadow-md transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <HelpCircle className="w-4 h-4 text-indigo-600" />
            <span>Test Yourself (Start Quiz)</span>
            <ChevronRight className="w-3.5 h-3.5 text-indigo-600" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sticky Sidebar Navigation (Desktop) */}
        <div className="hidden lg:block lg:col-span-3 no-print">
          <div className="sticky top-24 space-y-4">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-indigo-500" />
                <span>Contents Outline</span>
              </h3>
              <nav className="space-y-1 text-xs">
                <button
                  onClick={() => scrollToSection('sec-overview')}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                    activeSection === 'sec-overview'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Overview & Scope
                </button>
                <button
                  onClick={() => scrollToSection('sec-key-concepts')}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                    activeSection === 'sec-key-concepts'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Key Concepts ({notes.keyConcepts.length})
                </button>
                <button
                  onClick={() => scrollToSection('sec-definitions')}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                    activeSection === 'sec-definitions'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Important Definitions ({notes.definitions.length})
                </button>
                {notes.coreExplanations.map((exp, idx) => (
                  <button
                    key={exp.id}
                    onClick={() => scrollToSection(exp.id)}
                    className={`w-full text-left px-3 py-1.5 rounded-lg truncate transition-colors ${
                      activeSection === exp.id
                        ? 'bg-indigo-50 text-indigo-700 font-semibold'
                        : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {idx + 1}. {exp.heading}
                  </button>
                ))}
                <button
                  onClick={() => scrollToSection('sec-exam-essentials')}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                    activeSection === 'sec-exam-essentials'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Exam Essentials & Traps
                </button>
                <button
                  onClick={() => scrollToSection('sec-quick-recap')}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                    activeSection === 'sec-quick-recap'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Quick Revision Recap
                </button>
              </nav>
            </div>

            {/* Source Grounding Box */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/90 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Source Grounding</span>
                </span>
                <span className="text-[10px] bg-slate-200 px-1.5 py-0.5 rounded text-slate-700 font-mono">
                  {pageCount} Pages
                </span>
              </div>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                All points in these revision notes link directly to the source lecture document.
              </p>
              <button
                onClick={onOpenSourceInspector}
                className="w-full flex items-center justify-center gap-1 py-1.5 px-2 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 font-medium text-slate-700 text-[11px] transition-colors"
              >
                <span>Inspect Source Lecture</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Main Notes Content Area */}
        <div className="lg:col-span-9 space-y-8">
          {/* Note Title & Header */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                {notes.subject}
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs font-semibold text-slate-500">
                Exam Revision Document
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {notes.title}
            </h1>

            {/* Overview Section */}
            <div id="sec-overview" className="pt-3 border-t border-slate-100 scroll-mt-24">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Overview & Scope
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {notes.overview}
              </p>
            </div>
          </div>

          {/* Key Concepts Section */}
          <div id="sec-key-concepts" className="scroll-mt-24 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-indigo-600" />
                <span>Key Concepts</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                {notes.keyConcepts.length} Core Concepts
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {notes.keyConcepts.map((concept) => (
                <div
                  key={concept.id}
                  id={concept.id}
                  className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-indigo-300 shadow-xs transition-all space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">
                      {concept.title}
                    </h4>
                    <span
                      onClick={() => {
                        setHighlightedSource(concept.sourceReference);
                        onOpenSourceInspector();
                      }}
                      className="cursor-pointer px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 border border-slate-200 transition-colors"
                      title="Click to view source reference"
                    >
                      {concept.sourceReference}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {concept.summary}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Important Definitions Section */}
          <div id="sec-definitions" className="scroll-mt-24 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                <span>Important Definitions</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">Exam Terminology</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {notes.definitions.map((def, idx) => {
                const isCritical = def.importance === 'Critical';
                return (
                  <div
                    key={idx}
                    className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2 print-break-inside-avoid"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 text-sm">
                        {def.term}
                      </h4>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isCritical
                            ? 'bg-rose-50 text-rose-700 border border-rose-100'
                            : 'bg-amber-50 text-amber-700 border border-amber-100'
                        }`}
                      >
                        {def.importance}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {def.definition}
                    </p>
                    <div className="pt-2 flex justify-end">
                      <span
                        onClick={() => {
                          setHighlightedSource(def.sourceReference);
                          onOpenSourceInspector();
                        }}
                        className="cursor-pointer text-[10px] font-mono text-slate-400 hover:text-indigo-600 underline"
                      >
                        {def.sourceReference}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Core Explanations & Walkthroughs */}
          <div className="space-y-6">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>Core Explanations & Algorithmic Mechanics</span>
            </h3>

            {notes.coreExplanations.map((exp) => (
              <div
                key={exp.id}
                id={exp.id}
                className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4 scroll-mt-24 print-break-inside-avoid"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <h4 className="font-bold text-slate-900 text-base">
                    {exp.heading}
                  </h4>
                  <span
                    onClick={() => {
                      setHighlightedSource(exp.sourceReference);
                      onOpenSourceInspector();
                    }}
                    className="cursor-pointer self-start sm:self-auto px-2.5 py-0.5 rounded text-[11px] font-mono bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 border border-slate-200 transition-colors"
                  >
                    {exp.sourceReference}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {exp.content}
                </p>

                {/* Formula Callout if any */}
                {exp.formula && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center font-mono text-xs sm:text-sm text-indigo-900 font-semibold">
                    {exp.formula}
                  </div>
                )}

                {/* Code Snippet if any */}
                {exp.codeSnippet && (
                  <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-900 p-4 text-slate-100 font-mono text-xs overflow-x-auto">
                    <div className="flex items-center gap-1.5 text-slate-400 text-[10px] mb-2 uppercase tracking-wider">
                      <Code className="w-3 h-3" />
                      <span>Code Implementation</span>
                    </div>
                    <pre>
                      <code>{exp.codeSnippet}</code>
                    </pre>
                  </div>
                )}

                {/* Bulleted Points */}
                {exp.bullets && exp.bullets.length > 0 && (
                  <ul className="space-y-2 pt-1">
                    {exp.bullets.map((bullet, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2.5 text-xs text-slate-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 flex-shrink-0" />
                        <span className="leading-relaxed">{bullet}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>

          {/* Exam Essentials & Traps */}
          <div id="sec-exam-essentials" className="scroll-mt-24 space-y-4 print-break-inside-avoid">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>Exam Essentials & Common Pitfalls</span>
            </h3>

            <div className="space-y-4">
              {notes.examEssentials.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-amber-50/50 rounded-2xl border border-amber-200/80 p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span className="font-bold text-xs uppercase tracking-wider text-amber-900">
                        High-Yield Exam Takeaway
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">
                      {item.sourceReference}
                    </span>
                  </div>

                  <p className="text-xs text-slate-800 font-medium leading-relaxed">
                    {item.tip}
                  </p>

                  <div className="p-3 rounded-xl bg-white/80 border border-amber-200 text-xs text-rose-800 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <strong className="font-bold text-rose-900">Trap to Avoid: </strong>
                      <span>{item.trapToAvoid}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Recap Checklist */}
          <div id="sec-quick-recap" className="scroll-mt-24 bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4 print-break-inside-avoid">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                <span>Quick Revision Checklist</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">Summary Points</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {notes.quickRecap.map((point, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700">
                  <span className="w-4 h-4 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Primary CTA to Start Quiz */}
          <div className="no-print pt-4 text-center">
            <button
              onClick={onStartQuiz}
              className="inline-flex items-center gap-2 px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-2xl shadow-lg hover:shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <HelpCircle className="w-4 h-4" />
              <span>I've Reviewed the Notes — Take the Practice Quiz</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
