import React from 'react';
import { Sparkles, ArrowLeft, Key, Zap, BookOpen } from 'lucide-react';
import type { AppView, StudySession } from '../types';
import { getStoredApiKey } from '../services/aiService';

interface HeaderProps {
  currentView: AppView;
  currentSession: StudySession | null;
  onNavigateDashboard: () => void;
  onStartDemo: () => void;
  onOpenApiKeyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  currentSession,
  onNavigateDashboard,
  onStartDemo,
  onOpenApiKeyModal
}) => {
  const hasKey = !!getStoredApiKey();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Left Navigation */}
        <div className="flex items-center gap-3 sm:gap-5">
          {currentView !== 'dashboard' ? (
            <button
              onClick={onNavigateDashboard}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-indigo-600 bg-slate-100 hover:bg-indigo-50 rounded-xl transition-all border border-slate-200/80"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Dashboard</span>
            </button>
          ) : null}

          <div
            onClick={onNavigateDashboard}
            className="flex items-center gap-2.5 cursor-pointer select-none group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-500 flex items-center justify-center text-white shadow-sm shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                  Nexora
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                  StudyFlow AI
                </span>
              </div>
              <p className="text-[11px] text-slate-500 -mt-0.5 hidden sm:block">
                Your next-gen study workspace
              </p>
            </div>
          </div>
        </div>

        {/* Center Session Title if inside Workspace */}
        {currentView === 'workspace' && currentSession && (
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100/80 border border-slate-200 text-xs text-slate-700 max-w-sm truncate">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse flex-shrink-0" />
            <span className="font-medium truncate">{currentSession.title}</span>
          </div>
        )}

        {/* Right Actions */}
        <div className="flex items-center gap-2.5">
          {/* Quick Demo Trigger Button */}
          {currentView !== 'workspace' && (
            <button
              onClick={onStartDemo}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100/80 border border-amber-200 rounded-xl transition-all shadow-xs"
              title="Instantly test realistic lecture demo session"
            >
              <Zap className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span>Try Demo Lecture</span>
            </button>
          )}

          {/* API Key Modal Trigger */}
          <button
            onClick={onOpenApiKeyModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl border transition-all ${
              hasKey
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
            title="Configure Gemini API Key (Optional)"
          >
            <Key className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{hasKey ? 'Gemini Active' : 'Gemini AI'}</span>
          </button>

          {/* Hackathon Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-600">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>Prompt Wars</span>
          </div>
        </div>
      </div>
    </header>
  );
};
