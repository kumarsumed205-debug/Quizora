import React from 'react';
import { Plus, BookOpen, Clock, FileText, ArrowRight, Trash2, CheckCircle2, AlertTriangle, Sparkles, Zap, Award } from 'lucide-react';
import type { StudySession } from '../types';

interface DashboardViewProps {
  sessions: StudySession[];
  onNewSession: () => void;
  onOpenSession: (session: StudySession) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  onStartDemo: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  sessions,
  onNewSession,
  onOpenSession,
  onDeleteSession,
  onStartDemo
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white p-8 sm:p-10 shadow-xl border border-indigo-700/30">
        {/* Background glow effects */}
        <div className="absolute -right-16 -bottom-16 w-80 h-80 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-1/3 top-0 w-64 h-64 bg-violet-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold text-indigo-200">
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>Google for Developers × Hack2Skill • Prompt Wars</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            Ready to study smarter?
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Eliminate hours of student busywork. Upload your lecture PDF, slides, or notes to instantly generate exam-ready revision notes, test yourself with a grounded practice quiz, and identify exactly what to revise next.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={onNewSession}
              className="flex items-center gap-2 px-6 py-3 bg-white text-indigo-900 hover:bg-indigo-50 font-bold text-sm rounded-xl shadow-lg hover:shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4 text-indigo-700" />
              <span>Create Study Session</span>
            </button>

            <button
              onClick={onStartDemo}
              className="flex items-center gap-2 px-5 py-3 bg-indigo-800/80 hover:bg-indigo-700/80 text-white font-semibold text-sm rounded-xl border border-indigo-500/40 backdrop-blur-sm transition-all"
            >
              <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
              <span>⚡ Try Demo (Binary Search Trees)</span>
            </button>
          </div>
        </div>

        {/* 1-Flow Pill Highlight */}
        <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-indigo-500/30 flex items-center justify-center text-[10px] font-bold text-indigo-200">1</span>
            <span>Lecture Upload</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-indigo-500/30 flex items-center justify-center text-[10px] font-bold text-indigo-200">2</span>
            <span>Revision Notes</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-indigo-500/30 flex items-center justify-center text-[10px] font-bold text-indigo-200">3</span>
            <span>Practice Quiz</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-indigo-500/30 flex items-center justify-center text-[10px] font-bold text-indigo-200">4</span>
            <span>Weak-Topic Loop</span>
          </div>
        </div>
      </div>

      {/* Recent Study Sessions Header */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <span>Recent Study Sessions</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Continue your revision or review quiz performance
            </p>
          </div>
          <button
            onClick={onNewSession}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-xl border border-indigo-100 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Session</span>
          </button>
        </div>

        {/* Sessions Grid */}
        {sessions.length === 0 ? (
          <div className="text-center py-16 px-4 bg-white rounded-2xl border border-dashed border-slate-300">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-800">No study sessions yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
              Upload your first lecture slides or syllabus PDF to generate structured notes and practice questions.
            </p>
            <div className="flex justify-center gap-3">
              <button
                onClick={onNewSession}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold hover:bg-indigo-700 shadow-sm"
              >
                Create Study Session
              </button>
              <button
                onClick={onStartDemo}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-200"
              >
                Load Demo Lecture
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {sessions.map((session) => {
              const hasResults = !!session.results;
              const percentage = session.results?.percentage ?? 0;
              const isHigh = percentage >= 80;
              const isMedium = percentage >= 60 && percentage < 80;

              return (
                <div
                  key={session.id}
                  onClick={() => onOpenSession(session)}
                  className="group relative bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-200 cursor-pointer overflow-hidden p-5 flex flex-col justify-between"
                >
                  {/* Subject Tag & Delete Button */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {session.subject}
                      </span>
                      <button
                        onClick={(e) => onDeleteSession(session.id, e)}
                        className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title="Delete Session"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Session Title */}
                    <h3 className="font-bold text-slate-900 text-base group-hover:text-indigo-600 transition-colors line-clamp-2 mb-2">
                      {session.title}
                    </h3>

                    {/* File info */}
                    <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
                      <span className="flex items-center gap-1 truncate max-w-[140px]">
                        <FileText className="w-3 h-3 text-slate-400 flex-shrink-0" />
                        <span className="truncate">{session.fileName}</span>
                      </span>
                      <span className="flex items-center gap-1 flex-shrink-0">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{session.createdAt}</span>
                      </span>
                    </div>
                  </div>

                  {/* Bottom Score & Status Indicator */}
                  <div className="pt-4 border-t border-slate-100">
                    {hasResults ? (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                            <Award className="w-3.5 h-3.5 text-indigo-500" />
                            Quiz Score
                          </span>
                          <span
                            className={`font-bold ${
                              isHigh
                                ? 'text-emerald-600'
                                : isMedium
                                ? 'text-amber-600'
                                : 'text-rose-600'
                            }`}
                          >
                            {percentage}% ({session.results?.score}/{session.results?.totalQuestions})
                          </span>
                        </div>
                        {/* Progress meter bar */}
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              isHigh
                                ? 'bg-emerald-500'
                                : isMedium
                                ? 'bg-amber-500'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${percentage}%` }}
                          />
                        </div>

                        {/* Weak topics indicator if any */}
                        {session.results?.weakTopics && session.results.weakTopics.length > 0 ? (
                          <div className="flex items-center gap-1 text-[11px] text-amber-700 font-medium pt-1">
                            <AlertTriangle className="w-3 h-3 text-amber-500 flex-shrink-0" />
                            <span className="truncate">
                              {session.results.weakTopics.length} topic{session.results.weakTopics.length > 1 ? 's' : ''} needs revision
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-medium pt-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                            <span>Concepts mastered</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span className="text-slate-600">Quiz not taken yet</span>
                        <span className="inline-flex items-center gap-1 text-indigo-600 font-semibold group-hover:translate-x-0.5 transition-transform">
                          <span>Take Quiz</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
