import React, { useState } from 'react';
import {
  BookOpen,
  HelpCircle,
  Award,
  FileText,
  Clock,
  Printer,
  ChevronRight,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import type { StudySession, WorkspaceTab, QuizResult } from '../types';
import { RevisionNotesView } from './RevisionNotesView';
import { PracticeQuizView } from './PracticeQuizView';
import { QuizResultsView } from './QuizResultsView';
import { SourceInspectorModal } from './SourceInspectorModal';

interface StudySessionViewProps {
  session: StudySession;
  initialTab?: WorkspaceTab;
  onUpdateQuizResults: (results: QuizResult) => void;
}

export const StudySessionView: React.FC<StudySessionViewProps> = ({
  session,
  initialTab = 'notes',
  onUpdateQuizResults
}) => {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>(
    initialTab || (session.results ? 'results' : 'notes')
  );
  const [showSourceModal, setShowSourceModal] = useState<boolean>(false);

  const handleStartQuiz = () => {
    setActiveTab('quiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmitQuiz = (results: QuizResult) => {
    onUpdateQuizResults(results);
    setActiveTab('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRetakeQuiz = () => {
    setActiveTab('quiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToSection = (sectionId: string) => {
    setActiveTab('notes');
    setTimeout(() => {
      const elem = document.getElementById(sectionId);
      if (elem) {
        elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Flash highlight effect
        elem.classList.add('ring-4', 'ring-indigo-400', 'ring-offset-2');
        setTimeout(() => {
          elem.classList.remove('ring-4', 'ring-indigo-400', 'ring-offset-2');
        }, 2200);
      }
    }, 150);
  };

  const handleReviewAllNotes = () => {
    setActiveTab('notes');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50/50 pb-16">
      {/* Session Breadcrumbs & Tab Bar */}
      <div className="no-print bg-white border-b border-slate-200/80 sticky top-16 z-30 shadow-2xs backdrop-blur-md bg-white/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3">
            {/* Title & Metadata */}
            <div className="flex items-center gap-3 min-w-0">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 flex-shrink-0">
                {session.subject}
              </span>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                {session.title}
              </h2>
            </div>

            {/* Tab Navigation Buttons */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-2xl border border-slate-200 self-start sm:self-auto">
              <button
                onClick={() => setActiveTab('notes')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'notes'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Revision Notes</span>
              </button>

              <button
                onClick={() => setActiveTab('quiz')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'quiz'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Practice Quiz</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-100 text-indigo-700">
                  {session.quiz.length}
                </span>
              </button>

              {session.results && (
                <button
                  onClick={() => setActiveTab('results')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'results'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  <span>Results & Weak Topics</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      session.results.percentage >= 80
                        ? 'bg-emerald-100 text-emerald-800'
                        : session.results.percentage >= 60
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {session.results.percentage}%
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Tab Render */}
      <div>
        {activeTab === 'notes' && (
          <RevisionNotesView
            notes={session.notes}
            pageCount={session.pageCount}
            onStartQuiz={handleStartQuiz}
            onOpenSourceInspector={() => setShowSourceModal(true)}
          />
        )}

        {activeTab === 'quiz' && (
          <PracticeQuizView
            quiz={session.quiz}
            lectureTitle={session.title}
            onSubmitQuiz={handleSubmitQuiz}
            onBackToNotes={() => setActiveTab('notes')}
          />
        )}

        {activeTab === 'results' && session.results && (
          <QuizResultsView
            results={session.results}
            quiz={session.quiz}
            lectureTitle={session.title}
            onRetakeQuiz={handleRetakeQuiz}
            onNavigateToSection={handleNavigateToSection}
            onReviewAllNotes={handleReviewAllNotes}
          />
        )}
      </div>

      {/* Grounding Source Inspector Modal */}
      <SourceInspectorModal
        isOpen={showSourceModal}
        onClose={() => setShowSourceModal(false)}
        title={session.title}
        fileName={session.fileName}
        extractedText={session.extractedContent}
        pageCount={session.pageCount}
      />
    </div>
  );
};
