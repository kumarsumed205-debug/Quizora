import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, CheckCircle, AlertCircle, Trash2, ArrowRight, Zap, Sparkles, FileCode, Shield } from 'lucide-react';
import { formatFileSize } from '../services/documentExtractor';

interface UploadViewProps {
  onProcessFile: (file: File) => void;
  onStartDemo: () => void;
}

export const UploadView: React.FC<UploadViewProps> = ({ onProcessFile, onStartDemo }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt', 'md'];

  const validateAndSetFile = (file: File) => {
    setError(null);
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (!allowedExtensions.includes(ext)) {
      setError('Please upload a PDF, DOCX, PPTX, or TXT lecture file.');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setError('File size exceeds 25 MB limit. Please upload a smaller lecture document.');
      return;
    }
    setSelectedFile(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleRemove = () => {
    setSelectedFile(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = () => {
    if (!selectedFile) {
      setError('Please select or drop a lecture file to proceed.');
      return;
    }
    onProcessFile(selectedFile);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 space-y-8 animate-fadeIn">
      {/* Header section */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Automated Student Study Session</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Turn your lecture into a study session.
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-xl mx-auto">
          Upload your lecture material and we'll create concise revision notes and a practice quiz from it.
        </p>
      </div>

      {/* Main Upload Dropzone */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        {!selectedFile ? (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`group relative rounded-2xl border-2 border-dashed p-8 sm:p-12 text-center cursor-pointer transition-all duration-200 ${
              dragActive
                ? 'border-indigo-500 bg-indigo-50/50 scale-[1.01]'
                : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.md"
              onChange={handleChange}
              className="hidden"
            />

            <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
              <UploadCloud className="w-8 h-8" />
            </div>

            <h3 className="text-base font-semibold text-slate-900 mb-1">
              Drag & drop lecture files here, or <span className="text-indigo-600 underline">browse</span>
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mb-5">
              Supports PDF slides, Word documents (DOCX), PowerPoint presentations (PPTX), and plain notes.
            </p>

            {/* Supported formats pill badges */}
            <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] font-medium text-slate-500">
              <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-700">
                PDF (Recommended)
              </span>
              <span className="px-2 py-1 rounded-lg bg-slate-100 border border-slate-200">
                DOCX
              </span>
              <span className="px-2 py-1 rounded-lg bg-slate-100 border border-slate-200">
                PPTX
              </span>
              <span className="px-2 py-1 rounded-lg bg-slate-100 border border-slate-200">
                TXT
              </span>
              <span className="text-slate-400">up to 25 MB</span>
            </div>
          </div>
        ) : (
          /* Selected File Preview */
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 sm:p-5 rounded-2xl bg-indigo-50/60 border border-indigo-100">
              <div className="flex items-center gap-3.5 min-w-0">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center flex-shrink-0 shadow-sm">
                  <FileText className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-bold text-slate-900 truncate">
                    {selectedFile.name}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <span>{formatFileSize(selectedFile.size)}</span>
                    <span>•</span>
                    <span className="text-emerald-600 font-medium flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> Ready to process
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleRemove}
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl transition-colors"
                title="Remove file"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            {/* Action CTA Button */}
            <button
              onClick={handleSubmit}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md hover:shadow-indigo-500/20 transition-all hover:scale-[1.01] active:scale-[0.99]"
            >
              <span>Generate Study Session</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Demo Lecture Quick Option */}
      <div className="relative overflow-hidden rounded-2xl border border-amber-200/80 bg-gradient-to-r from-amber-50/90 via-amber-50/50 to-orange-50/70 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-amber-200 text-amber-900">
                Hackathon Instant Demo
              </span>
              <span className="text-xs font-semibold text-slate-800">No PDF on hand?</span>
            </div>
            <p className="text-xs text-slate-600">
              Load our curated university lecture: <strong>"Data Structures — Binary Search Trees & AVL Balancing"</strong> (14 slides, full notes & 7 grounded quiz questions).
            </p>
          </div>

          <button
            onClick={onStartDemo}
            className="flex-shrink-0 flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Zap className="w-3.5 h-3.5 fill-white" />
            <span>⚡ Load Demo Session</span>
          </button>
        </div>
      </div>

      {/* Privacy note */}
      <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
        <Shield className="w-3.5 h-3.5 text-slate-400" />
        <span>Files are parsed client-side in your browser. No files are permanently retained.</span>
      </div>
    </div>
  );
};
