import React from 'react';
import { Check, Loader2, Sparkles, BookOpen, Brain, ListChecks, HelpCircle, FileText } from 'lucide-react';

interface ProcessingViewProps {
  currentStepMessage: string;
  progressPercent: number;
  fileName: string;
}

export const ProcessingView: React.FC<ProcessingViewProps> = ({
  currentStepMessage,
  progressPercent,
  fileName
}) => {
  const steps = [
    { label: 'Reading lecture material & page layouts', threshold: 15, icon: FileText },
    { label: 'Extracting key concepts, formulas & definitions', threshold: 35, icon: Brain },
    { label: 'Structuring exam-oriented revision notes', threshold: 65, icon: BookOpen },
    { label: 'Formulating grounded practice quiz questions', threshold: 85, icon: HelpCircle },
    { label: 'Building interactive study session & weak-topic mapping', threshold: 95, icon: ListChecks }
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-8 animate-fadeIn">
      {/* AI Visualization Orb */}
      <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
        {/* Pulsing ring waves */}
        <div className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping" />
        <div className="absolute -inset-3 rounded-full bg-indigo-500/10 animate-pulse" />
        <div className="relative w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-600 flex items-center justify-center shadow-xl shadow-indigo-500/30 text-white">
          <Brain className="w-10 h-10 animate-pulse" />
        </div>
      </div>

      {/* Main Status Text */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-100">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Transforming Lecture</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
          Creating your Study Session...
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto truncate font-mono">
          {fileName}
        </p>
      </div>

      {/* Progress Bar */}
      <div className="max-w-md mx-auto space-y-2">
        <div className="w-full bg-slate-200/80 rounded-full h-2.5 overflow-hidden shadow-inner">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-600 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${Math.max(5, progressPercent)}%` }}
          />
        </div>
        <div className="flex justify-between items-center text-xs font-semibold text-slate-500">
          <span className="text-indigo-600">{currentStepMessage}</span>
          <span>{Math.round(progressPercent)}%</span>
        </div>
      </div>

      {/* Step Breakdown Cards */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 text-left max-w-lg mx-auto shadow-sm space-y-3.5">
        {steps.map((step, idx) => {
          const isDone = progressPercent > step.threshold;
          const isCurrent =
            progressPercent >= (idx === 0 ? 0 : steps[idx - 1].threshold) &&
            progressPercent <= step.threshold;
          const Icon = step.icon;

          return (
            <div
              key={idx}
              className={`flex items-center gap-3.5 p-2.5 rounded-xl transition-all ${
                isCurrent
                  ? 'bg-indigo-50/80 border border-indigo-100 text-indigo-900 font-semibold'
                  : isDone
                  ? 'text-slate-700'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-xs transition-colors ${
                  isDone
                    ? 'bg-emerald-500 text-white'
                    : isCurrent
                    ? 'bg-indigo-600 text-white animate-pulse'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isDone ? (
                  <Check className="w-4 h-4" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Icon className="w-3.5 h-3.5" />
                )}
              </div>
              <span className="text-xs sm:text-sm">{step.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
